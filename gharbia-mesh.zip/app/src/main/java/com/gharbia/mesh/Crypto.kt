package com.gharbia.mesh

import android.content.Context
import android.util.Base64
import java.nio.ByteBuffer
import java.security.*
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object Crypto {
    private val rnd = SecureRandom()

    fun newKeyPair(): KeyPair {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"))
        return g.generateKeyPair()
    }

    fun pubFrom(b: ByteArray): PublicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(b))
    fun privFrom(b: ByteArray): PrivateKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(b))

    fun idOf(pubBytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(pubBytes).take(8).joinToString("") { "%02x".format(it) }

    private fun key(priv: PrivateKey, pub: PublicKey): SecretKeySpec {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv); ka.doPhase(pub, true)
        val k = MessageDigest.getInstance("SHA-256").digest(ka.generateSecret())
        return SecretKeySpec(k, "AES")
    }

    /** ECDH مؤقت + AES-GCM: المستلم فقط يقدر يفك التشفير */
    fun encrypt(plain: ByteArray, recipient: PublicKey): ByteArray {
        val eph = newKeyPair()
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(eph.private, recipient), GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain)
        val ep = eph.public.encoded
        return ByteBuffer.allocate(2 + ep.size + 12 + ct.size)
            .putShort(ep.size.toShort()).put(ep).put(iv).put(ct).array()
    }

    fun decrypt(blob: ByteArray, myPriv: PrivateKey): ByteArray {
        val bb = ByteBuffer.wrap(blob)
        val n = bb.short.toInt()
        val ep = ByteArray(n).also { bb.get(it) }
        val iv = ByteArray(12).also { bb.get(it) }
        val ct = ByteArray(bb.remaining()).also { bb.get(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(myPriv, pubFrom(ep)), GCMParameterSpec(128, iv))
        return c.doFinal(ct)
    }

    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)
}

class Identity(val priv: PrivateKey, val pub: PublicKey) {
    val id: String = Crypto.idOf(pub.encoded)

    companion object {
        fun load(ctx: Context): Identity {
            val p = ctx.getSharedPreferences("id", Context.MODE_PRIVATE)
            val s = p.getString("priv", null)
            val u = p.getString("pub", null)
            if (s != null && u != null) {
                try { return Identity(Crypto.privFrom(Crypto.unb64(s)), Crypto.pubFrom(Crypto.unb64(u))) }
                catch (_: Exception) { }
            }
            val kp = Crypto.newKeyPair()
            p.edit().putString("priv", Crypto.b64(kp.private.encoded))
                .putString("pub", Crypto.b64(kp.public.encoded)).apply()
            return Identity(kp.private, kp.public)
        }
    }
}
