package com.gharbia.mesh

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private lateinit var nameEt: EditText
    private lateinit var startBtn: Button
    private lateinit var statusTv: TextView
    private lateinit var spinner: Spinner
    private lateinit var logTv: TextView
    private lateinit var scroll: ScrollView
    private lateinit var msgEt: EditText
    private lateinit var sendBtn: Button
    private var peerIds: List<String> = emptyList()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(12)) }

        root.addView(TextView(this).apply { text = "شبكة الغربية"; textSize = 22f; setTextColor(Color.parseColor("#1a5c3a")) })
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        nameEt = EditText(this).apply {
            hint = "اسمك"; setSingleLine()
            setText(getSharedPreferences("id", MODE_PRIVATE).getString("name", ""))
        }
        startBtn = Button(this).apply { setOnClickListener { toggle() } }
        row1.addView(nameEt, LinearLayout.LayoutParams(0, -2, 1f)); row1.addView(startBtn)
        root.addView(row1)

        statusTv = TextView(this).apply { setPadding(0, dp(6), 0, dp(6)); setTextColor(Color.DKGRAY) }
        root.addView(statusTv)
        spinner = Spinner(this); root.addView(spinner)

        logTv = TextView(this).apply { textSize = 16f; setPadding(dp(4), dp(8), dp(4), dp(8)) }
        scroll = ScrollView(this).apply { addView(logTv); setBackgroundColor(Color.parseColor("#f3f6f4")) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        msgEt = EditText(this).apply { hint = "اكتب رسالة"; imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine() }
        sendBtn = Button(this).apply { text = "إرسال"; setOnClickListener { send() } }
        row2.addView(msgEt, LinearLayout.LayoutParams(0, -2, 1f)); row2.addView(sendBtn)
        root.addView(row2)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Mesh.onChange = { render() }
        render()
    }

    override fun onPause() { Mesh.onChange = null; super.onPause() }

    private fun permissions(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_ADVERTISE; l += Manifest.permission.BLUETOOTH_CONNECT; l += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT <= 32) l += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) { l += Manifest.permission.NEARBY_WIFI_DEVICES; l += Manifest.permission.POST_NOTIFICATIONS }
        return l.toTypedArray()
    }

    private fun toggle() {
        if (Mesh.node != null) {
            startService(Intent(this, MeshService::class.java).setAction("stop")); return
        }
        val name = nameEt.text.toString().trim()
        if (name.isEmpty()) { Toast.makeText(this, "اكتب اسمك الأول", Toast.LENGTH_SHORT).show(); return }
        getSharedPreferences("id", MODE_PRIVATE).edit().putString("name", name).apply()
        val missing = permissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else launch(name)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        val needed = permissions().filter { it != Manifest.permission.POST_NOTIFICATIONS }
        if (needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED })
            launch(nameEt.text.toString().trim())
        else Toast.makeText(this, "لازم توافق على كل الصلاحيات عشان الشبكة تشتغل", Toast.LENGTH_LONG).show()
    }

    private fun launch(name: String) {
        startForegroundService(Intent(this, MeshService::class.java).putExtra("name", name))
    }

    private fun send() {
        val node = Mesh.node ?: return
        val i = spinner.selectedItemPosition
        val text = msgEt.text.toString().trim()
        if (i < 0 || i >= peerIds.size) { Toast.makeText(this, "مفيش حد اتعرف عليه لسه", Toast.LENGTH_SHORT).show(); return }
        if (text.isEmpty()) return
        if (node.send(peerIds[i], text)) msgEt.setText("")
    }

    private fun render() {
        val node = Mesh.node
        startBtn.text = if (node != null) "إيقاف" else "ابدأ"
        nameEt.isEnabled = node == null
        statusTv.text = node?.status ?: "متوقفة"
        val sel = peerIds.getOrNull(spinner.selectedItemPosition)
        val peers = node?.known?.values?.sortedBy { it.name } ?: emptyList()
        val ids = peers.map { it.id }
        if (ids != peerIds) {
            peerIds = ids
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                peers.map { "${it.name}  (${it.id.take(4)})" })
            val k = ids.indexOf(sel); if (k >= 0) spinner.setSelection(k)
        }
        synchronized(Mesh.log) { logTv.text = Mesh.log.joinToString("\n\n") }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
