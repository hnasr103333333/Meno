package com.gharbia.mesh

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class MeshService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { shutdown(); return START_NOT_STICKY }
        val name = intent?.getStringExtra("name") ?: "مجهول"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mesh", "الشبكة", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mesh")
            .setContentTitle("شبكة الغربية شغالة")
            .setContentText("بيدوّر على أجهزة قريبة وينقل الرسايل")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(1, n)
        if (Mesh.node == null) { Mesh.node = MeshNode(this, name).also { it.start() } }
        Mesh.notifyUi()
        return START_STICKY
    }

    private fun shutdown() {
        Mesh.node?.stop(); Mesh.node = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); Mesh.notifyUi()
    }

    override fun onDestroy() { Mesh.node?.stop(); Mesh.node = null; super.onDestroy() }
}
