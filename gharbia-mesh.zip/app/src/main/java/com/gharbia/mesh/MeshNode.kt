package com.gharbia.mesh

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import org.json.JSONObject
import java.security.PublicKey
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

data class Peer(val id: String, val name: String, val pub: PublicKey)

/** حالة مشتركة بين الخدمة والواجهة */
object Mesh {
    @Volatile var node: MeshNode? = null
    val log = ArrayList<String>()
    @Volatile var onChange: (() -> Unit)? = null
    fun addLog(s: String) { synchronized(log) { log.add(s); if (log.size > 500) log.removeAt(0) }; notifyUi() }
    fun notifyUi() { Handler(Looper.getMainLooper()).post { onChange?.invoke() } }
}

class MeshNode(ctx: Context, val myName: String) {
    private val SERVICE = "com.gharbia.mesh.v1"
    private val main = Handler(Looper.getMainLooper())
    private val client = Nearby.getConnectionsClient(ctx.applicationContext)
    private val identity = Identity.load(ctx.applicationContext)
    private val rnd = SecureRandom()

    val myId: String get() = identity.id
    val connected: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val requesting: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val found = ConcurrentHashMap<String, String>()      // endpointId -> nodeId
    val known = ConcurrentHashMap<String, Peer>()               // nodeId -> Peer
    private val announces = ConcurrentHashMap<String, String>()  // nodeId -> آخر إعلان (للإعادة للأجهزة الجديدة)
    private val seen = LinkedHashSet<String>()
    private val outbox = ArrayDeque<String>()
    @Volatile var status = "جارٍ البدء..."
    @Volatile private var running = false

    // ---------- تشغيل / إيقاف ----------
    fun start() {
        running = true
        client.startAdvertising("$myId|$myName", SERVICE, lifecycle,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
            .addOnFailureListener { setStatus("فشل الإعلان: ${it.message}") }
        client.startDiscovery(SERVICE, discovery,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
            .addOnFailureListener { setStatus("فشل البحث: ${it.message}") }
        main.post(tick)
        setStatus("يبحث عن أجهزة قريبة...")
    }

    fun stop() {
        running = false
        main.removeCallbacks(tick)
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
        connected.clear(); requesting.clear(); found.clear()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            flood(announcePacket(), null)
            for ((eid, other) in found) tryConnect(eid, other)
            main.postDelayed(this, 20000)
        }
    }

    // ---------- الاكتشاف والاتصال ----------
    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(eid: String, info: DiscoveredEndpointInfo) {
            val other = info.endpointName.substringBefore('|')
            if (other == myId) return
            found[eid] = other
            tryConnect(eid, other)
        }
        override fun onEndpointLost(eid: String) { found.remove(eid); requesting.remove(eid) }
    }

    /** الجهاز صاحب المعرّف الأصغر هو اللي يبدأ الاتصال، لتجنّب الطلبات المتزامنة */
    private fun tryConnect(eid: String, other: String) {
        if (myId > other || connected.contains(eid) || !requesting.add(eid)) return
        client.requestConnection("$myId|$myName", eid, lifecycle)
            .addOnFailureListener { requesting.remove(eid) }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(eid: String, info: ConnectionInfo) {
            client.acceptConnection(eid, payloadCb)
        }
        override fun onConnectionResult(eid: String, r: ConnectionResolution) {
            requesting.remove(eid)
            if (r.status.isSuccess) {
                connected.add(eid)
                sendRaw(eid, announcePacket().toString())
                announces.values.forEach { sendRaw(eid, it) }       // عرّفه بباقي الشبكة
                synchronized(outbox) { outbox.toList() }.forEach { sendRaw(eid, it) } // الرسايل المحفوظة
                refresh()
            }
        }
        override fun onDisconnected(eid: String) { connected.remove(eid); requesting.remove(eid); refresh() }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(eid: String, p: Payload) { p.asBytes()?.let { handle(eid, it) } }
        override fun onPayloadTransferUpdate(eid: String, u: PayloadTransferUpdate) {}
    }

    // ---------- الحزم ----------
    private fun randId() = ByteArray(8).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }

    private fun announcePacket(): JSONObject {
        val j = JSONObject().put("t", "A").put("id", randId()).put("ttl", 8)
            .put("src", myId).put("name", myName).put("pk", Crypto.b64(identity.pub.encoded))
        markSeen(j.getString("id"))
        return j
    }

    private fun markSeen(id: String): Boolean = synchronized(seen) {
        if (!seen.add(id)) return false
        if (seen.size > 3000) seen.remove(seen.first())
        true
    }

    private fun sendRaw(eid: String, s: String) { client.sendPayload(eid, Payload.fromBytes(s.toByteArray())) }
    private fun flood(j: JSONObject, except: String?) {
        val s = j.toString()
        connected.forEach { if (it != except) sendRaw(it, s) }
    }
    private fun relay(j: JSONObject, ttl: Int, from: String) {
        if (ttl <= 1) return
        j.put("ttl", ttl - 1)
        flood(j, from)
    }

    private fun handle(eid: String, bytes: ByteArray) {
        val j = try { JSONObject(String(bytes)) } catch (_: Exception) { return }
        val id = j.optString("id")
        if (id.isEmpty() || !markSeen(id)) return
        val ttl = j.optInt("ttl", 0)
        when (j.optString("t")) {
            "A" -> {
                val src = j.optString("src")
                if (src == myId) return
                try {
                    val pkb = Crypto.unb64(j.getString("pk"))
                    if (Crypto.idOf(pkb) != src) return          // رفض انتحال المعرّف
                    known[src] = Peer(src, j.optString("name", "?").take(40), Crypto.pubFrom(pkb))
                } catch (_: Exception) { return }
                j.put("ttl", ttl - 1); announces[src] = j.toString()
                refresh(); relay(JSONObject(j.toString()).put("ttl", ttl), ttl, eid)
            }
            "M" -> {
                if (j.optString("dst") == myId) {
                    try {
                        val plain = JSONObject(String(Crypto.decrypt(Crypto.unb64(j.getString("b")), identity.priv)))
                        val from = plain.optString("f")
                        Mesh.addLog("${known[from]?.name ?: from}: ${plain.optString("x")}")
                    } catch (_: Exception) { }
                } else if (ttl > 1) {
                    j.put("ttl", ttl - 1)
                    store(j.toString()); flood(j, eid)
                }
            }
        }
    }

    private fun store(s: String) = synchronized(outbox) { outbox.addLast(s); if (outbox.size > 200) outbox.removeFirst() }

    // ---------- إرسال ----------
    fun send(dstId: String, text: String): Boolean {
        val peer = known[dstId] ?: return false
        val inner = JSONObject().put("f", myId).put("x", text).toString().toByteArray()
        val j = JSONObject().put("t", "M").put("id", randId()).put("ttl", 10).put("dst", dstId)
            .put("b", Crypto.b64(Crypto.encrypt(inner, peer.pub)))
        markSeen(j.getString("id"))
        store(j.toString())
        flood(j, null)
        Mesh.addLog("أنا ← ${peer.name}: $text" + if (connected.isEmpty()) "  (محفوظة لحد ما يتوصل جهاز)" else "")
        return true
    }

    private fun setStatus(s: String) { status = s; Mesh.notifyUi() }
    private fun refresh() { status = "متصل بـ ${connected.size} جهاز • معروف ${known.size} في الشبكة"; Mesh.notifyUi() }
}
