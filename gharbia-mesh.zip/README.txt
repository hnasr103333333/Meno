1) ارفع محتويات المجلد ده كلها (بما فيها .github) على مستودع GitHub جديد.
2) تبويب Actions > Build APK > شغّله (أو بيشتغل لوحده عند الرفع).
3) بعد ما يخلص حمّل GharbiaMesh-apk من Artifacts، فك الضغط وثبّت app-debug.apk على الموبايلات.
